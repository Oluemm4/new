const toggle = document.getElementById('theme-toggle');
toggle.addEventListener('click', () => {
  document.body.classList.toggle('dark');
});
console.log("FUTB⚽LTIFY loaded. Dark mode toggle ready!");